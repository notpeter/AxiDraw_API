from packaging.version import parse
import requests
import unittest

from mock import MagicMock, patch

from axidrawinternal.axidraw_options import versions
from axidrawinternal.axidraw_options.versions import (
        DEV_AXIDRAW_CONTROL, AXIDRAW_CONTROL, EBB_FIRMWARE)
from axidrawinternal.plot_status import PlotStatus

from plotink import ebb_serial

from .. import MessageAssertionMixin

from plotink.plot_utils_import import from_dependency_import # plotink
message = from_dependency_import('ink_extensions_utils.message')

# python -m unittest discover in top-level package dir

web_versions = {'Hershey Advanced': '1.0.0',
                'Hershey Advanced (unstable)': '2.0.0',
                AXIDRAW_CONTROL: '10.0.0',
                DEV_AXIDRAW_CONTROL: '11.0.0',
                EBB_FIRMWARE: '100.0.0',
                'Some Other Software Version': 'ectoplasm'}
get_ret_value = MagicMock()
get_ret_value.text = repr(web_versions)

@patch.object(versions.requests, "get", return_value = get_ret_value)
@patch.object(ebb_serial, "query", return_value = "13,2")
@patch.object(versions, "logger")
class ReportVersionInfoTestCase(unittest.TestCase, MessageAssertionMixin):
    '''see test/test_integration for more relevant tests'''

    @staticmethod
    def _construct_default_params():
        ''' utility for setting up the many params for calling report_version_info '''
        plot_status = PlotStatus()
        plot_status.fw_version = web_versions[EBB_FIRMWARE]
        plot_status.port = "a port"
        return {
                "plot_status": plot_status,
                "check_updates": True,
                "current_version_string": web_versions[AXIDRAW_CONTROL],
                "preview": False,
                "message_fun": MagicMock()
                }

    def test_report_version_info(self, m_logger, _, __):
        '''
        testing the most basic case for report_version_info:
        * an AxiDraw is connected and the firmware version is the most up-to-date
        * internet is available and the current version matches the "stable" version
        '''
        params = self._construct_default_params()

        versions.report_version_info(**params)

        m_logger.error.assert_not_called()
        # e.g. "This is AxiDraw Control version 10.0.0."
        self.assertAnyMessageContains(params["message_fun"],
                ["AxiDraw", "version", web_versions[AXIDRAW_CONTROL]])
        # e.g. "Your AxiDraw Control software is up to date."
        self.assertAnyMessageContains(params["message_fun"],
                ["AxiDraw", "up", "date"])
        # e.g. "Your firmware is up to date; no updates are available.\n"
        self.assertAnyMessageContains(params["message_fun"],
                ["firmware", "up", "date"])
        # Also as part of normal function,
        # report_version_info outputs some information about voltage/current
        # e.g. 'Voltage readout: {voltage:d} (~ {scaled_voltage:.2f} V).'
        self.assertAnyMessageContains(params["message_fun"], ["voltage", "2"])
        # e.g. 'Current setpoint: {current:d} (~ {scaled_current:.2f} A).
        self.assertAnyMessageContains(params["message_fun"], ["current", "13"])

    def test_report_version_info__disabled_online_version_checking(self, m_logger, _, __):
        '''
        testing the case where `check_updates` is set to False (e.g. in the conf.py file)
        '''
        params = self._construct_default_params()
        params['check_updates'] = False

        versions.report_version_info(**params)

        # e.g. "Note: Online version checking disabled."
        self.assertAnyMessageContains(params["message_fun"], ["version", "check", "disabled"])

        # The following should be printed even if online version checking is disabled
        # e.g. "This is AxiDraw Control version 10.0.0"
        self.assertAnyMessageContains(params["message_fun"], ["AxiDraw", "version"])
        # and some kind of firmware version reporting
        self.assertAnyMessageContains(params["message_fun"], ["firmware"])
        m_logger.error.assert_not_called()

    def test_report_version_info__preview(self, m_logger, _, __):
        '''
        testing the case where `preview` is set to True
        '''
        params = self._construct_default_params()
        params['plot_status'].port = None
        params['preview'] = True

        versions.report_version_info(**params)

        # e.g. "\nFirmware version readout not available in preview mode."
        self.assertAnyMessageContains(params["message_fun"],
                ["firmware", "version", "not available", "preview"])
        m_logger.error.assert_not_called()

    @patch.object(versions, "report_ebb_version", side_effect=RuntimeError("this is an error"))
    def test_report_version_info__firmware_error(self, _, m_logger, __, ___):
        '''
        testing the case where there is an error while attempting
        to retrieve and report EBB firmware version information
        '''
        params = self._construct_default_params()
        params["plot_status"].port = "a port"

        versions.report_version_info(**params)

        # e.g. '\nUnable to retrieve AxiDraw EBB firmware version. (Error: this is an error) \n'
        expected_phrases = ["firmware", "unable", "this is an error"]
        self.assertAnyMessageContains(params["message_fun"], expected_phrases)
        self.assertAnyMessageContains(m_logger.error, expected_phrases)

    def test_report_version_info__fw_update_available(self, _, __, ___):
        params = self._construct_default_params()
        params["plot_status"].fw_version = "0" # really low, needs updating
        params["plot_status"].port = "a port"

        versions.report_version_info(**params)

        # e.g., 'An update is available to a newer version, 3.9.4.'
        self.assertAnyMessageContains(params["message_fun"],
                ["firmware", "update", "available"])

    def test_report_version_info__dev_software_newest(self, _, __, ___):
        '''
        testing the case where the current software is an early-release/development
        version, and it is the most recent dev version available
        '''
        params = self._construct_default_params()
        params["current_version_string"] = web_versions[DEV_AXIDRAW_CONTROL]

        versions.report_version_info(**params)

        # e.g. "~~ An early-release version ~~"
        self.assertAnyMessageContains(params["message_fun"], ["early", "version"])
        # e.g. "This is the newest available development version."
        self.assertAnyMessageContains(params["message_fun"], ["newest", "version", "dev"])
        # e.g. '(The current "stable" release is v. 10.0.0).'
        self.assertAnyMessageContains(params["message_fun"],
                ["current", "stable", web_versions[AXIDRAW_CONTROL]])

    def test_report_version_info__dev_software_update_available(self, _, __, ___):
        '''
        testing the case where the current software is an early-release/development
        import pdb; pdb.set_trace()
        version, and there are more recent development versions available
        '''
        params = self._construct_default_params()
        params["current_version_string"] = "10.0.1"
        assert parse(params["current_version_string"]) > parse(web_versions[AXIDRAW_CONTROL])
        assert parse(params["current_version_string"]) < parse(web_versions[DEV_AXIDRAW_CONTROL])

        versions.report_version_info(**params)

        # e.g. 'An update is available to a newer version, 11.0.0.'
        self.assertAnyMessageContains(params["message_fun"],
                ["update", "available", web_versions[DEV_AXIDRAW_CONTROL]])
        # e.g. "To update, please contact AxiDraw technical support."
        self.assertAnyMessageContains(params["message_fun"], ["update", "contact", "support"])

    def test_report_version_info__software_update_available(self, _, __, ___):
        params = self._construct_default_params()
        params["current_version_string"] = "9.0.0"
        assert parse(params["current_version_string"]) < parse(web_versions[AXIDRAW_CONTROL])

        versions.report_version_info(**params)

        # e.g. "An update is available to a newer version, 10.0.0."
        self.assertAnyMessageContains(params["message_fun"],
                ["update", "available", web_versions[AXIDRAW_CONTROL]])
        # e.g. "Please visit: axidraw.com/sw for the latest software."
        self.assertAnyMessageContains(params["message_fun"], ["axidraw.com/sw"])


    def test_report_version_info__server_timeout(self, m_logger, _, m_web_get):
        '''
        testing the case where the request to the version server timed out
        '''
        params = self._construct_default_params()
        m_web_get.side_effect=requests.exceptions.Timeout()

        versions.report_version_info(**params)

        # e.g. "Unable to check for updates online; connection timed out"
        self.assertAnyMessageContains(m_logger.error, ["time", "out"])

    def test_report_version_info__no_server(self, m_logger, _, m_web_get):
        '''
        testing the case where the version server cannot be contacted
        '''
        params = self._construct_default_params()
        m_web_get.side_effect=requests.exceptions.ConnectionError("this is a test")

        versions.report_version_info(**params)

        # e.g. 'Could not contact server to check for updates. Are you connected to the internet?
        #
        #(Error details: this is a test)'
        self.assertAnyMessageContains(m_logger.error, ["server", "connect", "this is a test"])

    def test_report_version_info__bad_response(self, m_logger, _, m_web_get):
        '''
        testing the case where there is a problem parsing the server's response
        '''
        valid_text = m_web_get.return_value.text
        try:
            # set up
            params = self._construct_default_params()
            m_web_get.return_value.text = "not a valid response"

            # execute
            versions.report_version_info(**params)

            # test
            # e.g. 'Could not parse server response. This is probably the server's fault.
            #
            # (Error details: {err_info}
            # '
            self.assertAnyMessageContains(m_logger.error, ["server", "parse", "syntax"])
        finally:
            # restore m_web_get mock so it doesn't mess up other tests
            m_web_get.return_value.text = valid_text

class MinFWVersionTestCase(unittest.TestCase):
    def test_min_fw_version(self):
        '''
        rough description of the function's intended behavior:
        if plot_status.fw_version is None, return None;
        otherwise return fw_version>=version_string
        '''

        version_string = "1.0.0"
        test_dict = { # key = plot_status.fw_version; value = expected result
            None: None,
            "1.0.0": True,
            "0.0.5": False,
            "1.0.1": True,
            }

        for fw_version, expected in test_dict.items():
            with self.subTest():
                # set up
                plot_status = PlotStatus()
                plot_status.fw_version = fw_version
                # run
                actual = versions.min_fw_version(plot_status, version_string)
                # test
                self.assertEqual(actual, expected,
                    f"Test failed for plot_status.fw_version set to {plot_status.fw_version}. "
                    f"Expected {expected}, got {actual}.")
